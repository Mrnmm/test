#include "LQueue.h"


void InitLQueue(LQueue *Q)//��ʼ������
{

Node *p=(Node *)malloc(sizeof(Q->length));
if(NULL==p)
{
	printf("error\n");
}
p->next=NULL;
Q->front=p;
Q->rear=p;
}
void DestoryLQueue(LQueue *Q)//���ٶ���
{
if(Q->front==Q->rear)
{
	free(Q->front);
	Q->front=NULL;
	Q->rear=NULL;
	printf("���ٳɹ�\n");
}
else
{
	while(Q->front)
	{
		Q->rear=Q->front->next;
		free(Q->front);
		Q->front=Q->rear;
	}
	Q->front=NULL;
}
}
Status IsEmptyLQueue(const LQueue *Q)//�ж϶����Ƿ�Ϊ��
{
if(Q->front==Q->rear)
{
	printf("���п���\n");
	return TRUE;
}
else
	return FALSE;
}
Status GetHeadLQueue(LQueue *Q, void *e)//�õ�����ͷԪ��
{
if(Q->front==Q->rear)
{
	return FALSE;
}

memcpy(e,Q->front->next->data,Q->length);

return TRUE;
}
int LengthLQueue(LQueue *Q)//������г���
{
int len=0;
while(Q->front!=Q->rear)
{
	len++;
	Q->front=Q->front->next;
}
return len;
}




Status EnLQueue(LQueue *Q, void *data)//���
{
Node *p=(Node *)malloc(sizeof(Node));
if(NULL==p)
{
	return FALSE;
}
p->data=(Node *)malloc(Q->length);
memcpy(p->data,data,Q->length);
p->next=NULL;
Q->rear->next=p;
Q->rear=p;
return TRUE;
}



Status DeLQueue(LQueue *Q)//����
{
if(IsEmptyLQueue(Q))
{
	return FALSE;
}
Node *p=(Node *)malloc(sizeof(Node));
p=Q->front->next;
Q->front->next=p->next;
if(p->next==NULL)
{
	Q->rear=Q->front;
}
free(p);
return TRUE;

}
void ClearLQueue(LQueue *Q)//��ն���
{
Node *p;
p=Q->front->next;
Q->rear=Q->front;
while(p)
{
	Q->front->next=p->next;
	free(p);
	p=Q->front->next;
}


}
Status TraverseLQueue(const LQueue *Q, void (*foo)(void *q))//��������
{
	if(IsEmptyLQueue(Q))
	{
		return FALSE;
	}
	Node *s=(Node *)malloc(Q->length);
	s=Q->front->next;
	int i=1;
	while(s!=NULL)
	{
		foo(s->data);
		s=s->next;
		i++;
	}

	return TRUE;
}

void LPrint(void *q)//��ӡ
{
	printf("������е�Ԫ��Ϊ\n");
	switch(type)
	{case 1:
	{
		printf("%c\n",*(char *)q);break;
	}
	case 2:
	{
		printf("%d\n",*(int *)q);break;
	}
	case 3:
	{
		printf("%f\n",*(float *)q);break;
	}
	default:break;
	}
}

int show(int choice,LQueue *Q)
{
int len;
switch(choice)
{

case 2:
printf("��������ӵ����ͣ�\n");
printf("1.char\n");
printf("2.int\n");
printf("3.float\n");
int a;
scanf("%d",&a);
type=a;
/*datatype[Q->length]=type;*/
switch(type)
{

	        case 1:
				{
				char  g;
				printf("please enter\n");
				scanf("%c",&g);
				char *p;p=&g;
				EnLQueue(Q,g);
				break;
				}
		case 2:
				{
					int g;
					printf("please enter\n");
					scanf("%d",&g);
					int *p;
					p=&g;
				         EnLQueue(Q,p);
				         break;
				}
		case 3:
				{
					float g;
					printf("please enter\n");
					scanf("%f",&g);
					float  *p;p=&g;
				        EnLQueue(Q,p);
				        break;
				}
	        default :break;
}break;
case 3:DeLQueue(Q);break;

case 4:
			switch(type)
			{
				case 1:{char c;
				GetHeadLQueue(Q,&c);
				printf("%c",c);break;}
				case 2:{int k;
				GetHeadLQueue(Q,&k);
				printf("%d",k);break;}
				case 3:{float  m;
				GetHeadLQueue(Q,&m);
				printf("%f",m);break;}
				default: break;
			}break;

case 5:
TraverseLQueue(Q,LPrint);break;
case 6:
IsEmptyLQueue(Q);break;
case 7:len=LengthLQueue(Q);
printf("%d",len);
break;
case 8:ClearLQueue(Q);break;
case 9:DestoryLQueue(Q);break;

}
return 1;
}





