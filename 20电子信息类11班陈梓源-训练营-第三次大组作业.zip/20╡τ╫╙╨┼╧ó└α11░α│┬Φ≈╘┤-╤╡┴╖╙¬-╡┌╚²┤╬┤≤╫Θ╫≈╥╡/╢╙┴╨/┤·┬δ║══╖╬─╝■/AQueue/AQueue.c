#include "AQueue.h"
void InitAQueue(AQueue *Q)
{
	int i;
	Q->length=MAXQUEUE;
	for(i=0;i<MAXQUEUE;i++)
	Q->data[i]=(void*)malloc(30);
	Q->front=Q->rear=0;
}

void DestoryAQueue(AQueue *Q)
{
if(Q->data[0]==NULL)
{
	printf("error");
}
for(int i=0;i<MAXQUEUE;i++)
{
	free(Q->data[i]);
}
Q->data[0]=NULL;
Q->front=Q->rear=0;

}




Status IsFullAQueue(const AQueue *Q)
{
if(Q->front==(Q->rear+1)%MAXQUEUE)
{
	printf("555");
	return TRUE;
}
else
	return FALSE;
}



Status IsEmptyAQueue(const AQueue *Q)
{
if(Q->front==Q->rear)
{
	return TRUE;
}
else
	return FALSE;
}
Status GetHeadAQueue(AQueue *Q, void *e)
{
if(Q->front==Q->rear)
{
	return FALSE;
}
else
{
   memcpy(e,Q->data[Q->front],20);//������e��
   return TRUE;
}



}
int LengthAQueue(AQueue *Q)
{
return (Q->rear-Q->front+MAXQUEUE)%MAXQUEUE;
}



Status EnAQueue(AQueue *Q, void *data)
{
if((Q->rear+1)%MAXQUEUE==Q->front)
{
	printf("��������\n");
}
if(IsEmptyAQueue(Q))
{
	memcpy(Q->data[Q->front],data,20);
	Q->rear=(Q->rear+1)%Q->length;
	return TRUE;
}
memcpy(Q->data[Q->rear],data,20);
Q->rear=(Q->rear+1)%Q->length;
return TRUE;
}

Status DeAQueue(AQueue *Q)
{
if(Q->front==Q->rear)
{
	printf("�����ǿյ�\n");
	return FALSE;
}

Q->front=(Q->front+1)%Q->length;
return TRUE;
}
void ClearAQueue(AQueue *Q)
{
	if(IsEmptyAQueue(Q))
	{
		printf("�����Ѿ�����\n");
	}

Q->front=Q->rear=0;
}
Status TraverseAQueue(const AQueue *Q, void (*foo)(void *q))
{
if(IsEmptyAQueue(Q))
{
	printf("�����ǿ��˵�\n");
	return FALSE;
}
int i=Q->front;
while(i!=Q->rear)
{
	type=datatype[i];
	foo(Q->data[i]);
	i++;
	if(i==MAXQUEUE-1)
	{
		i=0;
	}
}

return TRUE;
}
void APrint(void *q)
{
	printf("������е�Ԫ��Ϊ\n");
	switch(type)
	{case 1:
	{
		printf("%c\n",*(char *)q);break;
	}
	case 2:
	{
		printf("%d\n",*(int *)q);break;
	}
	case 3:
	{
		printf("%f\n",*(float  *)q);break;
	}
	default:break;
	}
}

int show(int choice,AQueue *Q)
{

int len;
switch(choice)
{

case 2:
printf("��������ӵ����ͣ�\n");
printf("1.char\n");
printf("2.int\n");
printf("3.float\n");
int a;
scanf("%d",&a);
type=a;
datatype[Q->rear]=type;
switch(type)
{

	       case 1:
				{
				char  g;
				printf("please enter\n");
				scanf("%c",&g);
				char   *p;p=&g;
				EnAQueue(Q,p);
				break;
				}
		case 2:
				{
					int g;
					printf("please enter\n");
					scanf("%d",&g);
					int *p;
					p=&g;
				         EnAQueue(Q,p);
				         break;
				}
		case 3:
				{
					float g;
					printf("please enter\n");
					scanf("%f",&g);
					float  *p;p=&g;
				        EnAQueue(Q,p);
				        break;
				}
	        default :break;
}break;
case 3:DeAQueue(Q);break;

case 4:
			switch(datatype[Q->front])
			{
				case 1:{char c;
				GetHeadAQueue(Q,&c);
				printf("%c",c);break;}
				case 2:{int k;
				GetHeadAQueue(Q,&k);
				printf("%d",k);break;}
				case 3:{float  m;
				GetHeadAQueue(Q,&m);
				printf("%f",m);break;}
				default: break;
			}break;

case 5:
TraverseAQueue(Q,APrint);break;
case 6:
IsEmptyAQueue(Q);break;
case 7:
IsFullAQueue(Q);break;
case 8:len=LengthAQueue(Q);
printf("%d",len);
break;
case 9:ClearAQueue(Q);break;
case 10:DestoryAQueue(Q);break;

}
return 1;
}
