#include <reg51.h>
#include <intrins.h>
unsigned char num[10]={0x3f,0x06,0x5b,0x4f,0x66,0x6d,0x7d,0x07,0x7f,0x6f};
void delay(unsigned int ms)
{unsigned int i,j;
	for(i=ms;i>0;i--)
	{for(j=110;j>0;j--)
		{
			;
		}
	}
}
void main()
{
	unsigned char i=0;
	P0=0x00;
	while(1)
	{
		P0=num[i];
		i=(i+1)%10;
		delay(1000);
	}
}