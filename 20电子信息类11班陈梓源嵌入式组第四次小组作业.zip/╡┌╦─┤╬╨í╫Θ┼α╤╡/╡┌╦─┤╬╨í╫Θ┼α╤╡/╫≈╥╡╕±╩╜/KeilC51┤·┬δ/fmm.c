#include <reg51.h>
sbit beep=P0^5;
void delay_ms(unsigned z)
{
unsigned x,y;
for(x=z;x>0;x--)
{
for(y=110;y>0;y--)
{
;
}
}
}
void main()
{
while(1)
{
beep=0;
delay_ms(1000);
beep=1;
delay_ms(1000);
}
}
