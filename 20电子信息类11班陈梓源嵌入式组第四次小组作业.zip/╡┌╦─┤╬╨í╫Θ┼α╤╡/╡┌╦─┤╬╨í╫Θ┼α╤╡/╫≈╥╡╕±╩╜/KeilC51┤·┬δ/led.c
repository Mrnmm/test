#include <reg51.h>
#include <stdio.h>
#include <intrins.h>
void delay()
{
int i,j;
for(i=0;i<500;i++)
{
  for(j=0;j<125;j++)
  {;
  }
}
}
void main()
{while(1)
{P3=0xfe;delay();
P3=0xfd;delay();
P3=0xfb;delay();
P3=0xf7;delay();
P3=0xef;delay();
P3=0xdf;delay();
P3=0xbf;delay();
P3=0x7f;delay();
}
}
 
