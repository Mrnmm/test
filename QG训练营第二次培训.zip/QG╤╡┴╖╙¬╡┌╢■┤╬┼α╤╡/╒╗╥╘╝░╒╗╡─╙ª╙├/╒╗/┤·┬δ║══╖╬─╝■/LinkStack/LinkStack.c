
#include "../head/LinkStack.h"







Status initLStack(LinkStack *s)//��ʼ��ջ
{
s=(LinkStack *)malloc(sizeof(LinkStack));
s->top=NULL;
s->count=0;
return SUCCESS;
}
Status isEmptyLStack(LinkStack *s)//�ж�ջ�Ƿ�Ϊ��
{
if(s->count==0)
{
	printf("ջ����\n");

}
	return SUCCESS;

}
Status getTopLStack(LinkStack *s,ElemType *e)//�õ�ջ��Ԫ��
{
	if(s->count==0)
	{
		return ERROR;
	}
	else
	{
		*e=s->top->data;//
                return SUCCESS;
	}
}
Status clearLStack(LinkStack *s)//���ջ
{

        LinkStackPtr p;
	p=s->top;
	s->top=s->top->next;//
	s->count--;
	free(p);

return SUCCESS;
}
Status destroyLStack(LinkStack *s)//����ջ
{
free(s);
printf("���ٳɹ�\n");
return SUCCESS;
}
Status LStackLength(LinkStack *s,int *length)//���ջ����
{
      *length=s->count;
      return SUCCESS;
}
Status pushLStack(LinkStack *s,ElemType data)//��ջ
{
	LinkStackPtr p=(LinkStackPtr)malloc(sizeof(StackNode));
	p->data=data;
	p->next=s->top;
	s->top=p;
	s->count++;
	return SUCCESS;
}
Status popLStack(LinkStack *s,ElemType *data)//��ջ
{
	LinkStackPtr p;
	if(s->top==NULL)
	{
		return ERROR;
	}
	*data=s->top->data;
	p=s->top;
	s->top=s->top->next;
	free(p);
	s->count--;
	return SUCCESS;
}
