#include "../head/SqStack.h"


Status initStack(SqStack *s,int sizes)//��ʼ��ջ
{
	s->elem=(ElemType *)malloc(sizes*sizeof(ElemType));
	if(s->elem==NULL)
	{
		printf("error\n");
		return ERROR;
	}
	s->top=-1;
	s->size=sizes;
	return SUCCESS;
}




Status isEmptyStack(SqStack *s)//�ж�ջ�Ƿ�Ϊ��
{
if(s->top==-1)
{
	printf("stack empty\n");

        return SUCCESS;}
else
	return ERROR;
}




Status getTopStack(SqStack *s,ElemType *e)//�õ�ջ��Ԫ��
{
if(s->top==-1)
{
	printf("���а�ջ�ǿյ�\n");
	return ERROR;
}
else
{
	e=&(s->elem[s->top]);
	printf("ջ��Ԫ��Ϊ:%d\n",*e);
	return SUCCESS;

}
}






Status clearStack(SqStack *s)//���ջ
{
s->top=-1;
return SUCCESS;
}





Status destroyStack(SqStack *s)//����ջ
{
free(s);
return SUCCESS;
}





Status stackLength(SqStack *s,int *length)//���ջ����
{
	if(s->top==-1)
	{
		return ERROR;
	}
	else
	{


		length=(s->top+1);
		printf("ջ�ĳ���Ϊ:%d",length);
		return SUCCESS;
	}

}





Status pushStack(SqStack *s,ElemType data)//��ջ
{
	if(s->top==s->size-1)
	{
		return ERROR;
	}
		else
		{  s->top++;
		  s->elem[s->top]=data;
	          return SUCCESS;
		}
}





Status popStack(SqStack *s,ElemType *data)//��ջ
{
	if(s->top==-1)
	{
		return ERROR;
	}
	else
	{
	*data=s->elem[s->top];
	s->top--;
	return SUCCESS;
	}
}
