#include "calculator.h"


int main()
{
	char a[100]={0};
	int  i=0,b=0, num1,num2;
	Stack num,fuhao;//��������ջnum�����֣�fuhao�ŷ���
	if(Initstack(&num)!=SUCCESS||Initstack(&fuhao)!=SUCCESS)
	{
		printf("���а����䲻��ȥ\n");
		exit(1);
	}
	printf("********************����������Ҫʵ�ֵ��㷨*********************\n");
	scanf("%s",a);//����
	while(a[i]!='\0'||Emptystack(&fuhao)!=SUCCESS)
	{
		if(a[i]>='0'&&a[i]<='9')
		{
			b=b*10+a[i]-'0';
			i++;
			if(a[i]<'0'||a[i]>'9')
			{
				push(&num,b);
				b=0;
			}

		}
		else
		{
			if(Emptystack(&fuhao)==SUCCESS||(Gettop(&fuhao)=='('&&a[i]!=')')||compare(a[i])>compare(Gettop(&fuhao)))
			{
				push(&fuhao,a[i]);
				i++;
				continue;
			}
			if(Gettop(&fuhao)=='('&&a[i]==')')
			{
				pop(&fuhao);
				i++;
				continue;
			}
			if((a[i]=='\0')&&(Emptystack(&fuhao)!=SUCCESS)||(a[i]==')')&&(Gettop(&fuhao)!=')')||(compare(a[i])>=compare(Gettop(&fuhao))))
			{
				switch(pop(&fuhao))
				{
					case '+':
					num1=pop(&num);num2=pop(&num);
					push(&num,num1+num2);
					break;
					case '-':
					num1=pop(&num);
					num2=pop(&num);
					push(&num,num2-num1);
					break;
					case '*':
					num1=pop(&num);
					num2=pop(&num);
					push(&num,num1*num2);
					break;
					case '/':
					num1=pop(&num);
					num2=pop(&num);
					push(&num,num2/num1);
					;break;

				}
				continue;
			}
		}
	}

	printf("%d",Gettop(&num));
	return 0;//������
}
