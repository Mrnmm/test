#include "calculator.h"


int Initstack(Stack *s)
{
	s->top=NULL;
	s->count=0;
	return SUCCESS;
}
int Emptystack(Stack *s)
{
	if(s->count==0)
	{
		return SUCCESS;
	}
	else
		{return ERROR;}
}
int push(Stack *s,int e)
{
	linkStackPtr p=( linkStackPtr)malloc(sizeof(node));
	if(p==NULL)
	{
		return ERROR;
	}
	p->data=e;
	p->next=s->top;
	s->top=p;
	s->count++;
	return SUCCESS;

}

int Gettop(Stack *s)
{
	if(s->top==NULL)
	{
		return ERROR;

	}
	return (s->top->data);
}
int pop(Stack *s)
{
	int e;
	if(s->top==NULL)
	{
		return ERROR;
	}
	 linkStackPtr p=s->top;
	 e=p->data;
	 s->top=p->next;
	 free(p);
	 s->count--;
	 return e;
}
int compare(char ch)
{
	switch(ch)
	{
		case'-':return 1;
		case'+':return 1;
		case '/':return 2;
		case '*':return 2;
		case '(':return 3;
		default :return 0;
	}
}
