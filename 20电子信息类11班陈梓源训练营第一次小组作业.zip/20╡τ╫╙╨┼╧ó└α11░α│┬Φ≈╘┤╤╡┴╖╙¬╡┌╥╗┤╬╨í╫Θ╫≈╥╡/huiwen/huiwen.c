#include "huiwen.h"

int start(char s[],int left,int right)
{
	int length;
	length=strlen(s);
	while(left>=0&&right<length&&s[left]==s[right])
	{
		left--;
		right++;
	}
	return right-left-1;
}
