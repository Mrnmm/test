
#include "huiwen.h"

int main()
{
  int length,i,j=0;
  char a[100],s[100];
  printf("�������ַ���\n");
  gets(s);
  length=strlen(s);

  if(s[0]=='\0'||length<1)
  {
  	printf("error\n");
  }
  int b=0,c=0;
  for(i=0;i<length;i++)
{   int length1=start(s,i,i);
    int length2=start(s,i,i+1);
    int length;
     if(length1>=length2)
	length=length1;
     else
     {
     	length=length2;
     }
     if(length>c-b)
     {
     	b=i-(length-1)/2;
     	c=i+length/2;
     }
}
for(i=b;i<=c;i++)
{
	a[j]=s[i];
	j++;
}
printf("%s",a);
system("pause");
return 0;
}
