
#include "bianxing.h"
char *convert(char *s,int num)
{
 if(num==1)
{
 	return s;
}
 int len =strlen(s);
 char *array=(char*)malloc(sizeof(char)*(len+1));
 int i=0,k=0,pos=0;
 for(i=0;i<num;i++)
 {
 	for(int j=0;j<len/(2*num-2)+2;j++)
	{

		pos=j*(2*num-2)+i;
		int pos1=pos-2*i;
		if(pos1>=0&&pos1<len&&i!=0&&i!=num-1)
		{
			array[k++]=s[pos1];
		}
		if(pos<len)
		{
			array[k++]=s[pos];
		}
	}
 }


array[k]='\0';
return array;
}
