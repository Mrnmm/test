#include "../inc/qgsort.h"
void insertSort(int *a,int n)
{       int q=0,g=0;
	for(int i=1;i<n;i++)
	{
		g=a[i];
		q=i-1;
		while(q>=0&&g<a[q])
		{
			a[q+1]=a[q];
			q--;
		}
		a[q+1]=g;

	}

}


void MergeArray(int *a,int begin,int mid,int end,int *temp)
{
	/*int len=end-begin+1;*/
	int q=begin;
	int i=begin;
	int j=mid+1;
	while(i!=mid+1&&j!=end+1)
	{
		if(a[i]<=a[j])
		{
			temp[q++]=a[i++];
		}
		else
		{
			temp[q++]=a[j++];
		}

	}
	while(i!=mid+1)
	{
		temp[q++]=a[i++];
	}
	while(j!=end+1)
	{
		temp[q++]=a[j++];
	}
	for(i=begin;i<=end;i++)
	{
		a[i]=temp[i];
	}
}
void MergeSort(int *a,int begin,int end,int *temp)
{
if(begin<end)
{
	int mid=begin+(end-begin)/2;
	MergeSort(a,begin,mid,temp);
	MergeSort(a,mid+1,end,temp);
	MergeArray(a,begin,mid,end,temp);
}
}
void QuickSort_Recursion(int *a, int begin, int end)
{
int i=begin;
int j=end;
if(i>j)
{
	return ;
}
int k=a[i];
while(i<j)
	{
		while(i<j&&a[j]>k)
		{
			j--;


		}
		a[i]=a[j];
		if(i<j&&a[i]<=k)
		{
			i++;

		}
		a[j]=a[i];
	}
	a[i]=k;
	QuickSort_Recursion(a,begin,i-1);
	QuickSort_Recursion(a,i+1,end);

}

void QuickSort(int *a,int size)
{
if(a==NULL||size<=0)
{
	return ;
}
Partition(a,0,size-1);

}
int Partition(int *a, int begin, int end)
{
int i,j,flag;
if(begin<end)
{
	flag=a[begin];
	i=begin;
	j=end;
	while(i!=j)
	{
		while(a[j]>=flag&&i<j)
		{
			j--;
		}
		while(a[i]<=flag&&i<j)
		{
			i++;
		}
		if(i<j)
		{
			int temp=a[i];
			a[i]=a[j];
			a[j]=temp;
		}
	}
	a[begin]=a[i];
	a[i]=flag;
	Partition(a,begin,i-1);
	Partition(a,i+1,end);


}
return 0;
}
void CountSort(int *a, int size , int max)
{
int *b,*c;
int i;
c=(int *)malloc(sizeof(int)*max);
b=(int *)malloc(sizeof(int )*size);
for(i=0;i<max;i++)
{
	c[i]=0;
}
for(i=0;i<size;i++)
{
	c[a[i]]+=1;
}
for(i=1;i<max;i++)
{
	c[i]=c[i-1]+c[i];
}
for(i=size-1;i>=0;i--)
{
	b[c[a[i]]-1]=a[i];
	c[a[i]]-=1;
}
for(i=0;i<size;i++)
{
	a[i]=b[i];
}
	free(c);
	free(b);

}
void RadixCountSort(int *a,int size)
{
int i,max=a[0],base=1;
for(i=1;i<size;i++)
{
	if(a[i]>max)
	{
		max=a[i];
	}
}
int *b=(int *)malloc(sizeof(int)*size);
while(max/base>0)
{
	int c[10]={0};
	for(i=0;i<size;i++)
	{
		c[a[i]/base%10]++;
	}
	for(i=1;i<10;i++)
	{
		c[i]+=c[i-1];
	}
	for(i=size-1;i>=0;i--)
	{
		b[c[a[i]/base%10]-1]=a[i];
		c[a[i]/base%10]--;
	}
	for(i=0;i<size;i++)
	{
		a[i]=b[i];
	}
	base=base*10;
}
}
void ColorSort(int *a,int size)
{
int *p,*p1,*p2;
p=a;
p1=a;
int temp;
p2=&a[size-1];
for(int i=0;i<size;p++)
{
	while(p!=p2)
	{if((*p)==2)
	{
         temp=(*p);
         (*p)=(*p2);
         (*p2)=temp;
	}
	if((*p)==0)
	{
	temp=(*p);
         (*p)=(*p1);
         (*p1)=temp;
	}
	}
}
}


int findnum(int *a,int begin,int end,int k)
{
	int b=begin;
	int c=end;
	int d=a[b];
	int e=0;
	while(b<c)
	{
		if(e==0)
		{
			if(a[c]>d)
			{
				c--;
			}
			else
			{
				a[b++]=a[c];
				e=1;
			}
		}
		else
		{
			if(a[b]<d)
			{
				b++;
			}
			else
			{
				a[c--]=a[b];
				e=0;
			}
		}
	}
	if(k==b)
	{
		return d;
	}
	else if(k>b)
	{
		return findnum(a,b+1,end,k);
	}
	else
	{
		return findnum(a,begin,b-1,k);
	}
}

int first(int *a)//10000������
{

	int choice;
	printf("����������Ҫ֪���ܹ��㷨������ʱ��\n");
	printf("1.��������\n");
	printf("2.�鲢����\n");
	printf("3.�������򣨵ݹ飩\n");
	printf("4.�������򣨷ǵݹ飩\n");
	printf("5.��������\n");
	printf("6.��������\n");
	scanf("%d",&choice);
	/*int n=10000;*/
	int *temp=NULL;
        temp=(int *)malloc(sizeof(int));
	double t1,t2;
	/*FILE *fp;
	fp=fopen("numbers.txt","r");
	if(fp==NULL)
	{
		printf("��ʧ��\n");
		exit(1);
	}
	while(fscanf(fp,"%d",&x[n])!=EOF)
		n++;*/
	printf("����ʱ������:\n");
	switch(choice)
	{
	case 1:
        t1=clock();
	insertSort(a,10000);
	t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
	case 2:
	t1=clock();
        MergeSort(a,0,9999,temp);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
	case 3:
	t1=clock();
	QuickSort_Recursion(a,0,9999);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
        case 4:
	t1=clock();
	QuickSort(a,10000);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
        case 5:
	t1=clock();
	CountSort(a,10000,10000);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
        case 6:
	t1=clock();
	RadixCountSort(a,10000);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));

		}
return 0;



}

int second(int *a)//50000������
{

	int choice;
	printf("����������Ҫ֪���ܹ��㷨������ʱ��\n");
	printf("1.��������\n");
	printf("2.�鲢����\n");
	printf("3.�������򣨵ݹ飩\n");
	printf("4.�������򣨷ǵݹ飩\n");
	printf("5.��������\n");
	printf("6.��������\n");
	scanf("%d",&choice);
	/*int n=50000;*/
	int *temp=NULL;
        temp=(int *)malloc(sizeof(int));
	double t1,t2;
	/*FILE *fp;
	fp=fopen("numbers.txt","r");
	if(fp==NULL)
	{
		printf("��ʧ��\n");
		exit(1);
	}
	while(fscanf(fp,"%d",&x[n])!=EOF)
		n++;*/
	printf("����ʱ������:\n");
	switch(choice)
	{
	case 1:
        t1=clock();
	insertSort(a,50000);
	t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
	case 2:
	t1=clock();
        MergeSort(a,0,49999,temp);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
	case 3:
	t1=clock();
	QuickSort_Recursion(a,0,49999);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
        case 4:
	t1=clock();
	QuickSort(a,50000);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
        case 5:
	t1=clock();
	CountSort(a,50000,50000);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
        case 6:
	t1=clock();
	RadixCountSort(a,50000);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
	}
return 0;



}

int three(int *a)
{

	int choice;
	printf("����������Ҫ֪���ܹ��㷨������ʱ��\n");
	printf("1.��������\n");
	printf("2.�鲢����\n");
	printf("3.�������򣨵ݹ飩\n");
	printf("4.�������򣨷ǵݹ飩\n");
	printf("5.��������\n");
	printf("6.��������\n");
	scanf("%d",&choice);
	/*int n=200000;*/
	int *temp=NULL;
        temp=(int *)malloc(sizeof(int));
	double t1,t2;
	/*FILE *fp;
	fp=fopen("numbers.txt","r");
	if(fp==NULL)
	{
		printf("��ʧ��\n");
		exit(1);
	}
	while(fscanf(fp,"%d",&x[n])!=EOF)
		n++;*/
	printf("����ʱ������:\n");
	switch(choice)
	{
	case 1:
        t1=clock();
	insertSort(a,200000);
	t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
	case 2:
	t1=clock();
        MergeSort(a,0,199999,temp);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
	case 3:
	t1=clock();
	QuickSort_Recursion(a,0,199999);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
        case 4:
	t1=clock();
	QuickSort(a,200000);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
        case 5:
	t1=clock();
	CountSort(a,200000,200000);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
        break;
        case 6:
	t1=clock();
	RadixCountSort(a,200000);
        t2=clock();
        printf("��ʱ:%f��",(t2-t1));
	}
return 0;




}









